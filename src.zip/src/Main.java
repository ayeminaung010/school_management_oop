// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Contact contact1 = new Contact("yangon","Yangon","Myanmar","098475934","aung@gmail.com");

        Teachers teacher1 = new Teachers(50000 , contact1 , "T01","Daw Aye","C01");
        Instructors instructor1 = new Instructors(50000 , contact1 , "I01","Daw Mya","C01");
        Students student1 = new Students("S01","Aye Aye","C01",contact1);
        student1.showInfo();
    }
}