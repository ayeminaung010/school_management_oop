public abstract class Address {

    String city;
    String state;
    String country;

    public Address(String city,String state,String country){
        this.country = country;
        this.city = city;
        this.state = state;
    }

}
